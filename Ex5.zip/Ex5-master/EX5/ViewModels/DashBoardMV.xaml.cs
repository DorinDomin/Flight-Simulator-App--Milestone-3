﻿using EX5.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EX5.ViewModels
{
    public partial class DashBoardMV : INotifyPropertyChanged
    {
        IModel model;
        public DashBoardMV(IModel m)
        {
            this.model = m;
            model.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            {
                NotifyPropertyChanged("VM_" + e.PropertyName);
            };
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propname)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propname));
            }
        }

        public string VM_Indicatedheadingdeg
        {
            get
            {
                return model.Indicatedheadingdeg;
            }
        }
        public string VM_Indicatedverticalspeed
        {
            get
            {
                return model.Indicatedverticalspeed;
            }
        }
        public string VM_Indicatedgroundspeed
        {
            get
            {
                return model.Indicatedgroundspeed;
            }
        }
        public string VM_Indicatedspeed
        {
            get
            {
                return model.Indicatedspeed;
            }
        }
        public string VM_Indicatedaltitudegps
        {
            get
            {
                return model.Indicatedaltitudegps;
            }
        }
        public string VM_Internalrolldeg
        {
            get
            {
                return model.Internalrolldeg;
            }
        }
        public string VM_Internalpitchdeg
        {
            get
            {
                return model.Internalpitchdeg;
            }
        }
        public string VM_Indicatedaltitudealt
        {
            get
            {
                return model.Indicatedaltitudealt;
            }
        }
        public void start()
        {
            model.start();
        }
        public string VM_IP
        {
            get
            {
                return model.IP;
            }
            set
            {
                model.IP = value;
            }
        }
        public string VM_Port
        {
            get
            {
                return model.Port;
            }
            set
            {
                model.Port = value;
            }
        }
        public string VM_ColorRed
        {
            get
            {
                return model.ColorRed;
            }
            set
            {
                model.ColorRed = value;
            }
        }
        public string VM_ColorGreen
        {
            get
            {
                return model.ColorGreen;
            }
            set
            {
                model.ColorGreen = value;
            }
        }
        public string VM_ColorOrange
        {
            get
            {
                return model.ColorOrange;
            }
            set
            {
                model.ColorOrange = value;
            }
        }
        public string VM_ColorPurple
        {
            get
            {
                return model.ColorPurple;
            }
            set
            {
                model.ColorPurple = value;
            }
        }
        public bool VM_Isflybutton
        {
            get
            {
                return model.Isflybutton;
            }
            set
            {
                model.Isflybutton = value;
            }
        }
        public bool VM_Isstopbutton
        {
            get
            {
                return model.Isstopbutton;
            }
            set
            {
                model.Isstopbutton = value;
            }
        }

    }
}
