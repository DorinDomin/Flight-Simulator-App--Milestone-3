﻿using EX5.Model;
using Microsoft.Maps.MapControl.WPF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EX5.ViewModels
{
    /// <summary>
    /// Interaction logic for MapVM.xaml
    /// </summary>
    public partial class MapVM : UserControl
    {
        private Map appMap;
        private IModel model;
        public Map AppMap
        {
            get
            {
                return appMap;
            }
            set
            {
                this.appMap = value;
                model.MyM = value;
            }
        }
        public MapVM(IModel m)
        {
            this.model = m;
            model.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            {
                NotifyPropertyChanged("VM_" + e.PropertyName);
            };
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propname)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propname));
        }
        public Location VM_Plane
        {
            get
            {
                return model.Plane;
            }
        }

        public void start()
        {
            model.start();
        }

    }
}