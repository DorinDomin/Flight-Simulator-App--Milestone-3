﻿using System;
using System.ComponentModel;
using System.Windows;
using EX5.Model;
using Microsoft.Maps.MapControl.WPF;
using EX5.ViewModels;
using EX5.Views;

namespace EX5
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            Pushpin plane = new Pushpin();
            Application.Current.Properties["globalm"] = new Model.Model(new TelnetClient());
            InitializeComponent();
        }

        //public static readonly DependencyProperty AileronProperty = Joystick.AileronProperty.AddOwner(typeof(MainWindow), new PropertyMetadata(true));
    }
}
