﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EX5.Views
{
    /// <summary>
    /// Interaction logic for Joystick.xaml
    /// </summary>
    public partial class JoystickView:UserControl
    {
        public bool Pressed;
        //Storyboard storyboard;
        ViewModels.JoystickMV vm;
        public JoystickView() {
            InitializeComponent();
            if (Application.Current.Properties["globalvm"] == null)
            {
                vm= new ViewModels.JoystickMV((Model.Model)(Application.Current.Properties["globalm"]));
                Application.Current.Properties["globalvm"] = vm;
            }
            else
            {
                vm = (ViewModels.JoystickMV)(Application.Current.Properties["globalvm"]);
            }
            DataContext = vm;
            AileronVal.Text = "0";
            ThrottleVal.Text = "0";
            RudderVal.Text = "0";
            ElevatorVal.Text = "0";
            //storyboard = Knob.FindResource("CenterKnob") as Storyboard;
        }

        /*private void Knob_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Pressed = true;
            Mouse.Capture(Knob);
        }

        private void Knob_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Pressed = false;
            storyboard.Begin();
            RudderVal.Text = "0";
            ElevatorVal.Text = "0";
            Mouse.Capture(null);
        }

        private void Knob_MouseMove(object sender, MouseEventArgs e)
        {
            //Mouse.Capture(Knob);
            bool flag = false; 
            if (Pressed == false)
            {
            }
            else
            {
                Point point = e.GetPosition(Base);
                if (86>=Math.Sqrt(Math.Pow(point.X-170,2)+Math.Pow(point.Y-170,2)))
                {
                    knobPosition.X = point.X - 170;
                    knobPosition.Y = point.Y - 170;
                    if (Math.Round((-(point.Y - 170) / 86)-0.01, 2) == -1)
                    {
                        ElevatorVal.Text = "-1";
                        RudderVal.Text = "0";
                        flag = true;
                    }
                    else
                    {
                        ElevatorVal.Text = Math.Round((-(point.Y - 170) / 86),2).ToString();
                        if (ElevatorVal.Text == "1")
                        {
                            RudderVal.Text = "0";
                            flag = true;
                        }
                    }
                    if (Math.Round(((point.X - 170) / 86) + 0.01, 2) == 1)
                    {
                        RudderVal.Text = "1";
                        ElevatorVal.Text = "0";
                    }
                    else
                    {
                        if (!flag)
                        {
                            RudderVal.Text = Math.Round(((point.X - 170) / 86), 2).ToString();
                            if (RudderVal.Text == "-1")
                            {
                                ElevatorVal.Text = "0";
                            }
                        }

                    }
                    flag = false;
                }
                else
                {
                    double dist = Math.Sqrt(Math.Pow(point.X-170, 2) + Math.Pow(point.Y-170, 2))-86;
                    knobPosition.X = ((86*point.X+dist*170)/(dist+86))-170;
                    knobPosition.Y =((86 * point.Y + dist * 170) / (dist + 86)) - 170;
                    if(Math.Round((knobPosition.X / 86), 2).ToString() == "1")
                    {
                        RudderVal.Text = "1";
                        ElevatorVal.Text = "0";
                        return;
                    }
                    if (Math.Round((knobPosition.X / 86), 2).ToString() == "-1")
                    {
                        RudderVal.Text = "-1";
                        ElevatorVal.Text = "0";
                        return;
                    }
                    if (Math.Round(-(knobPosition.Y / 86), 2).ToString() == "-1")
                    {
                        RudderVal.Text = "0";
                        ElevatorVal.Text = "-1";
                        return;
                    }
                    if (Math.Round(-(knobPosition.Y / 86), 2).ToString() == "1")
                    {
                        RudderVal.Text = "0";
                        ElevatorVal.Text = "1";
                        return;
                    }
                    RudderVal.Text = Math.Round((knobPosition.X / 86), 2).ToString();
                    ElevatorVal.Text = Math.Round((-(knobPosition.Y) / 86), 2).ToString();


                }
            }
        }*/

        private void SliderAileron_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            AileronVal.Text = SliderAileron.Value.ToString();
        }

        private void SliderThrottle_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ThrottleVal.Text = SliderThrottle.Value.ToString();
        }

/*        private void Knob_MouseLeave(object sender, MouseEventArgs e)
        {
            Pressed = false;
            storyboard.Begin();
            RudderVal.Text = "0";
            ElevatorVal.Text = "0";
        }*/

        /*private void centerKnob_Completed(object sender, EventArgs e)
        {
            knobPosition.X = 0;
            knobPosition.Y = 0;
            storyboard.Stop();
        }*/
    }
}
