﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EX5.Model;

namespace EX5.Views
{
    public partial class DBView : UserControl
    {
        ViewModels.DashBoardMV vm;

        public DBView()
        {
            InitializeComponent();            
            vm = new ViewModels.DashBoardMV((Model.Model)(Application.Current.Properties["globalm"]));
            //Application.Current.Properties["flybutton"] = FlyButton;
            vm.VM_Isflybutton = true;
            vm.VM_Isstopbutton = false;
            DataContext = vm;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            vm.VM_ColorOrange = "white";
            vm.VM_ColorPurple = "white";
            vm.VM_Isflybutton = false;
            //vm.VM_Isstopbutton = true;
            vm.start();
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            vm.VM_Isflybutton = true;
            vm.VM_Isstopbutton = false;
        }
    }
}
