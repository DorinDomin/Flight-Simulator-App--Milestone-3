﻿using Microsoft.Maps.MapControl.WPF;
using System;
using System.ComponentModel;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace EX5.Model
{
    /// <summary>
    /// Interaction logic for model.xaml
    /// </summary>
    public interface IModel : INotifyPropertyChanged
    {
        string Indicatedheadingdeg { set; get; }
        string Indicatedverticalspeed { set; get; }
        string Indicatedgroundspeed { set; get; }
        string Indicatedspeed { set; get; }
        string Indicatedaltitudegps { set; get; }
        string Internalrolldeg { set; get; }
        string Internalpitchdeg { set; get; }
        string Indicatedaltitudealt { set; get; }
        double Throttle { set; get; }
        double Aileron { set; get; }
        double Elevator { set; get; }
        double Rudder { set; get; }
        string IP { set; get; }
        string Port { set; get; }
        string ColorRed { set; get; }
        string ColorGreen { set; get; }
        string ColorOrange { set; get; }
        string ColorPurple { set; get; }
        Location Plane { set; get; }
        Map MyM { set; }

        bool Isflybutton { set; get; }
        bool Isstopbutton { set; get; }

        void connect(string ip, int port);
        void start();
    }
    public interface ITelnetClient
    {
        void connect(string ip, int port);
        void write(string command);
        void write2server(string command, string value);
        void flush();
        string read();
        string[] read8();
        void get8(string c1,string c2, string c3, string c4, string c5, string c6, string c7, string c8);
        void sendjoy(string a1, string v1, string a2, string v2, string a3, string v3, string a4, string v4);
        NetworkStream GetStream();
    }
    public class TelnetClient : ITelnetClient
    {
        private TcpClient client;
        public void connect(string ip, int port)
        {
            client = new TcpClient();
            client.Connect(IPAddress.Parse(ip), port);
        }

        public string read()
        {
            byte[] data = new byte[client.ReceiveBufferSize];
            client.GetStream().Read(data, 0, data.Length);
            string str = Encoding.Default.GetString(data);
            /*str = str.Split(' ')[2];
            return str.Substring(1, str.Length - 2);*/
            return str;
        }

        public void write(string command)
        {
            byte[] message = Encoding.ASCII.GetBytes("get " + command + "\r\n");
            client.GetStream().Write(message, 0, message.Length);
        }
        public void write2server(string command,string value)
        {
            byte[] message = Encoding.ASCII.GetBytes("set " + command + " "+value+"\r\n");
            client.GetStream().Write(message, 0, message.Length);
        }
        public void flush()
        {
            client.GetStream().Flush();
        }
        public NetworkStream GetStream()
        {
            return client.GetStream();
        }
        public void get8(string c1,string c2,string c3,string c4,string c5,string c6,string c7,string c8)
        {
            byte[] message = Encoding.ASCII.GetBytes("get " + c1 + "\r\n"+ "get " + c2 + "\r\n" + "get " + c3 + "\r\n" + "get " + c4 + "\r\n" + "get " + c5 + "\r\n" +
                "get " + c6 + "\r\n" + "get " + c7 + "\r\n" + "get " + c8 + "\r\n");
            client.GetStream().Write(message, 0, message.Length);
        }
        public string[] read8()
        {
            byte[] data = new byte[client.ReceiveBufferSize];
            client.GetStream().Read(data, 0, data.Length);
            string str = Encoding.Default.GetString(data);
            /*str = str.Split(' ')[2];
            return str.Substring(1, str.Length - 2);*/
            return str.Split('\n');
        }
        public void sendjoy(string a1, string v1, string a2, string v2, string a3, string v3, string a4, string v4)
        {
            byte[] message = Encoding.ASCII.GetBytes("set " + a1 + " " + v1 + "\r\n"+ "set " + a2 +
                " " + v2 + "\r\n" + "set " + a3 + " " + v3 + "\r\n" + "set " + a4 + " " + v4 + "\r\n");
            client.GetStream().Write(message, 0, message.Length);
        }
    }
    public partial class Model : IModel
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private string indicatedheadingdeg, indicatedverticalspeed, indicatedgroundspeed, indicatedspeed, indicatedaltitudegps, internalrolldeg, internalpitchdeg, indicatedaltitudealt;
        double aileron, throttle,elevator,rudder;
        private string ip;
        private string port;
        bool isflybutton,isstopbutton;
        private string colorred = "white";
        private string colorgreen = "white";
        private string colororange = "white";
        private string colorpurple = "white";
        ITelnetClient client;
        private Location plane;
        private Map myM = null;
        private Pushpin pin;


        public Model(ITelnetClient telnetClient)
        {
            this.client = telnetClient;
        }
        public void NotifyPropertyChanged(string propname)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propname));
            }
        }
        public string Indicatedheadingdeg
        {
            get
            {
                return indicatedheadingdeg;

            }
            set
            {
                indicatedheadingdeg = value;
                this.NotifyPropertyChanged("Indicatedheadingdeg");
            }
        }
        public string Indicatedverticalspeed
        {
            get
            {
                return indicatedverticalspeed;

            }
            set
            {
                indicatedverticalspeed = value;
                this.NotifyPropertyChanged("Indicatedverticalspeed");
            }
        }
        public string Indicatedgroundspeed
        {
            get
            {
                return indicatedgroundspeed;

            }
            set
            {
                indicatedgroundspeed = value;
                this.NotifyPropertyChanged("Indicatedgroundspeed");
            }
        }
        public string Indicatedspeed
        {
            get
            {
                return indicatedspeed;

            }
            set
            {
                indicatedspeed = value;
                this.NotifyPropertyChanged("Indicatedspeed");
            }
        }
        public string Indicatedaltitudegps
        {
            get
            {
                return indicatedaltitudegps;

            }
            set
            {
                indicatedaltitudegps = value;
                this.NotifyPropertyChanged("Indicatedaltitudegps");
            }
        }
        public string Internalrolldeg
        {
            get
            {
                return internalrolldeg;

            }
            set
            {
                internalrolldeg = value;
                this.NotifyPropertyChanged("Internalrolldeg");
            }
        }
        public string Internalpitchdeg
        {
            get
            {
                return internalpitchdeg;

            }
            set
            {
                internalpitchdeg = value;
                this.NotifyPropertyChanged("Internalpitchdeg");
            }
        }
        public string Indicatedaltitudealt
        {
            get
            {
                return indicatedaltitudealt;

            }
            set
            {
                indicatedaltitudealt = value;
                this.NotifyPropertyChanged("Indicatedaltitudealt");
            }
        }
        public string IP
        {
            get
            {
                return ip;
            }
            set
            {
                ip = value;
                NotifyPropertyChanged("IP");
            }
        }
        public string Port
        {
            get
            {
                return port;
            }
            set
            {
                port = value;
                NotifyPropertyChanged("Port");
            }
        }
        public double Throttle
        {
            get
            {
                return throttle;
            }
            set
            {
                throttle = value;
                NotifyPropertyChanged("Throttle");
            }
        }
        public double Aileron
        {
            get
            {
                return aileron;
            }
            set
            {
                aileron = value;
                NotifyPropertyChanged("Aileron");
            }
        }
        public double Elevator
        {
            get
            {
                return elevator;
            }
            set
            {
                elevator = value;
                NotifyPropertyChanged("Elevator");
            }
        }
        public double Rudder
        {
            get
            {
                return rudder;
            }
            set
            {
                rudder = value;
                NotifyPropertyChanged("Rudder");
            }
        }
        public bool Isflybutton
        {
            get
            {
                return isflybutton;
            }
            set
            {
                isflybutton = value;
                NotifyPropertyChanged("Isflybutton");
            }
        }
        public bool Isstopbutton
        {
            get
            {
                return isstopbutton;
            }
            set
            {
                isstopbutton = value;
                NotifyPropertyChanged("Isstopbutton");
            }
        }
        public Location Plane
        {
            get
            {
                return plane;
            }
            set
            {
                plane = value;
                NotifyPropertyChanged("Plane");
            }
        }
        public Map MyM
        {
            set
            {
                myM = value;
            }
        }

        public void connect(string ip, int port)
        {
            client.connect(ip, port);
        }

        public void start()
        {
            Thread t = new Thread(delegate ()
            {
                Thread.Sleep(1000);
                ColorOrange = "White";
                Location fly = new Location(32.009444, 34.876944);
                Location MapCenter;

                try
                {
                    connect(IP, Int32.Parse(Port));
                    ColorGreen = "GreenYellow";
                }
                catch
                {
                    int i = 1;
                    while (i<3)
                    {
                        try
                        {
                            connect("127.0.0.1", 5402);
                            ColorRed = "Red";
                            break;
                        }
                        catch
                        {
                            i++;
                            if (i == 3)
                            {
                                Isflybutton = true;
                                Isstopbutton = false;
                                ColorOrange = "Orange";
                                return;
                            }
                            else
                            {
                                Thread.Sleep(1000);
                            }
                        }
                    }
                }
                Isstopbutton = true;
                String[] temp = new string[8];
                temp[0] = "/instrumentation/heading-indicator/indicated-heading-deg";
                temp[1] = "/instrumentation/gps/indicated-vertical-speed";
                temp[2] = "/instrumentation/gps/indicated-ground-speed-kt";
                temp[3] = "/instrumentation/airspeed-indicator/indicated-speed-kt";
                temp[4] = "/instrumentation/gps/indicated-altitude-ft";
                temp[5] = "/instrumentation/attitude-indicator/internal-roll-deg";
                temp[6] = "/instrumentation/attitude-indicator/internal-pitch-deg";
                temp[7] = "/instrumentation/altimeter/indicated-altitude-ft";
                string ailadd = "/controls/flight/aileron";
                string throtadd = "/controls/engines/current-engine/throttle";
                string elevadd = "/controls/flight/elevator";
                string rudderadd = "/controls/flight/rudder";
                NetworkStream networkStream = client.GetStream();
                Indicatedheadingdeg = "loading..";
                Indicatedverticalspeed = "loading..";
                Indicatedgroundspeed = "loading..";
                Indicatedspeed = "loading..";
                Indicatedaltitudegps = "loading..";
                Internalrolldeg = "loading..";
                Internalpitchdeg = "loading..";
                Indicatedaltitudealt = "loading..";
                byte[] buff=new byte[1];
                int sleeplen = 50;
                string[] s;
                bool flag = true;

                /*while (myM == null)
                {
                    Thread.Sleep(100);
                }
                client.write("/position/latitude-deg");
                fly.Latitude = Double.Parse(client.read());
                client.write("/position/longitude-deg");
                fly.Longitude = Double.Parse(client.read());
                // Update view.
                Application.Current.Dispatcher.Invoke(() =>
                {
                    //mym.Center = new Location(32.009444, 34.876944);
                    myM.Center = new Location(fly);
                });*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                while (true)
                {
                    /*while (networkStream.DataAvailable == true)
                    {
                        networkStream.Read(buff, 0, 1);
                    }
                    client.write(temp[0]);
                    Indicatedheadingdeg = client.read();
                    client.write(temp[1]);
                    Indicatedverticalspeed = client.read();
                    client.write(temp[2]);
                    Indicatedgroundspeed = client.read();
                    client.write(temp[3]);
                    Indicatedspeed = client.read();
                    client.write(temp[4]);
                    Indicatedaltitudegps = client.read();
                    client.write(temp[5]);
                    Internalrolldeg = client.read();
                    client.write(temp[6]);
                    Internalpitchdeg = client.read();
                    client.write(temp[7]);
                    Indicatedaltitudealt = client.read();*/
                    flag = true;
                    client.get8(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7]);
                    Thread.Sleep(sleeplen);
                    s = client.read8();
                    if (s.Length == 9)
                    {
                        Indicatedheadingdeg = s[0];
                        Indicatedverticalspeed = s[1];
                        Indicatedgroundspeed = s[2];
                        Indicatedspeed = s[3];
                        Indicatedaltitudegps = s[4];
                        Internalrolldeg = s[5];
                        Internalpitchdeg = s[6];
                        Indicatedaltitudealt = s[7];
                        
                        for (int k = 0; k < 8; k++)
                        {
                            if (s[k] == "ERR")
                            {
                                ColorPurple = "#ab20fd";
                                flag = false;
                            }
                        }
                        if (flag)
                        {
                            ColorPurple = "white";
                        }
                    }
                    else
                    {
                        sleeplen += 10;
                    }


                    client.write2server(ailadd, Aileron.ToString());
                    client.read();
                    client.write2server(throtadd, Throttle.ToString());
                    client.read();
                    client.write2server(elevadd, Elevator.ToString());
                    client.read();
                    client.write2server(rudderadd, Rudder.ToString());
                    client.read();
                    /*client.sendjoy(ailadd, Aileron.ToString(), throtadd, Throttle.ToString(), elevadd, Elevator.ToString(), rudderadd, Rudder.ToString());
                    Thread.Sleep(sleeplen);
                    client.read();
                    while (networkStream.DataAvailable == true)
                    {
                       client.read();
                    }*/


                    /*                    while (networkStream.DataAvailable == true)
                                        {
                                            networkStream.Read(buff, 0, 1);
                                        }*/
                    //Thread.Sleep(50);

                    /*client.write("/position/latitude-deg");
                    fly.Latitude = Double.Parse(client.read());
                    client.write("/position/longitude-deg");
                    fly.Longitude = Double.Parse(client.read());
                    Thread.Sleep(50);
                    // Update pushpin in view.
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        myM.Children.Clear();
                        pin.Location = new Location(fly);
                        myM.Children.Add(this.pin);
                        MapCenter = myM.Center;
                        // NEEDS TO UPDATE VIA MAP ZOOM
                        if (pin.Location.Latitude - myM.Center.Latitude >= 0.3)
                        {
                            myM.Center = new Location(MapCenter.Latitude + 0.1, MapCenter.Longitude);

                        }
                        if (myM.Center.Latitude - pin.Location.Latitude >= 0.3)
                        {
                            myM.Center = new Location(MapCenter.Latitude - 0.1, MapCenter.Longitude);
                        }
                        if (pin.Location.Longitude - myM.Center.Longitude >= 0.3)
                        {
                            myM.Center = new Location(MapCenter.Latitude, MapCenter.Longitude + 0.1);
                        }
                        if (myM.Center.Longitude - pin.Location.Longitude >= 0.3)
                        {
                            myM.Center = new Location(MapCenter.Latitude, MapCenter.Longitude - 0.1);
                        }

                    });*/



                    if (!Isstopbutton)
                    {
                        ColorPurple = "white";
                        Indicatedheadingdeg = "";
                        Indicatedverticalspeed = "";
                        Indicatedgroundspeed = "";
                        Indicatedspeed = "";
                        Indicatedaltitudegps ="";
                        Internalrolldeg = "";
                        Internalpitchdeg = "";
                        Indicatedaltitudealt = "";
                        ColorRed = "white";
                        ColorGreen = "white";
                        return;
                    }
                }
            });
            t.Start();
        }
        public string ColorRed
        {
            set
            {
                this.colorred = value;
                NotifyPropertyChanged("ColorRed");
            }
            get
            {
                return this.colorred;
            }
        }
        public string ColorGreen
        {
            set
            {
                this.colorgreen = value;
                NotifyPropertyChanged("ColorGreen");
            }
            get
            {
                return this.colorgreen;
            }
        }
        public string ColorOrange
        {
            set
            {
                this.colororange = value;
                NotifyPropertyChanged("ColorOrange");
            }
            get
            {
                return this.colororange;
            }
        }
        public string ColorPurple
        {
            set
            {
                this.colorpurple = value;
                NotifyPropertyChanged("ColorPurple");
            }
            get
            {
                return this.colorpurple;
            }
        }
    }
}
